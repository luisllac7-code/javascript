const { useState } = React;

function ResultadoVoley() {
  const [mostrarDetalle, setMostrarDetalle] = useState(false);

  const partido = {
    equipo1: "Alianza Lima",
    equipo2: "Fluminense",
    fecha: "25 de octubre de 2025",
    marcador: {
      alianza: 3,
      fluminense: 2
    },
    sets: [
      { set: 1, resultado: "25 - 23" },
      { set: 2, resultado: "22 - 25" },
      { set: 3, resultado: "25 - 21" },
      { set: 4, resultado: "20 - 25" },
      { set: 5, resultado: "15 - 12" }
    ]
  };

  const manejarClick = () => {
    setMostrarDetalle(!mostrarDetalle);
  };

  return (
    <div className="container">
      <h1 className="titulo">🏐 Resultado del Partido de Vóley 2025</h1>
      <h2>{partido.equipo1} vs {partido.equipo2}</h2>
      <p className="fecha">📅 {partido.fecha}</p>

      <div className="resultado">
        <span className="equipo">{partido.equipo1}</span>
        <span className="marcador">{partido.marcador.alianza}</span>
        <span className="separador">-</span>
        <span className="marcador">{partido.marcador.fluminense}</span>
        <span className="equipo">{partido.equipo2}</span>
      </div>

      <button className="boton" onClick={manejarClick}>
        {mostrarDetalle ? "Ocultar sets" : "Ver detalle por sets"}
      </button>

      {mostrarDetalle && (
        <ul className="lista-sets">
          {partido.sets.map((s, index) => (
            <li key={index}>Set {s.set}: {s.resultado}</li>
          ))}
        </ul>
      )}

      <footer className="footer">
        <p>Hecho por mi<strong> Luis A.Llacsahuanga A.</strong> | Javacript - 2025</p>
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<ResultadoVoley />);
