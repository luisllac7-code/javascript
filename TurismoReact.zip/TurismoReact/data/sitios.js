// Base de datos portable de sitios turísticos del Perú
const sitiosTuristicos = [
    {
        id: 1,
        nombre: "Machu Picchu",
        ubicacion: "Cusco",
        descripcion: "La ciudadela inca más famosa del mundo, considerada una de las nuevas maravillas. Un lugar místico rodeado de montañas y nubes que te transportará al pasado.",
        imagen: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=400&h=250&fit=crop",
        rating: 5,
        precio: "S/. 200",
        categoria: "Arqueológico",
        duracion: "1 día completo"
    },
    {
        id: 2,
        nombre: "Centro Histórico de Cusco",
        ubicacion: "Cusco",
        descripcion: "La antigua capital del Imperio Inca, con calles empedradas, iglesias coloniales y una rica historia que se respira en cada rincón.",
        imagen: "https://images.unsplash.com/photo-1531065208531-4036c0dba3ca?w=400&h=250&fit=crop",
        rating: 4,
        precio: "S/. 50",
        categoria: "Histórico",
        duracion: "Medio día"
    },
    {
        id: 3,
        nombre: "Arequipa - Ciudad Blanca",
        ubicacion: "Arequipa",
        descripcion: "Ciudad colonial construida con sillar blanco volcánico, rodeada por tres volcanes imponentes. Su centro histórico es Patrimonio de la Humanidad.",
        imagen: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=250&fit=crop",
        rating: 4,
        precio: "S/. 80",
        categoria: "Colonial",
        duracion: "1 día"
    },
    {
        id: 4,
        nombre: "Amazonía de Iquitos",
        ubicacion: "Loreto",
        descripcion: "Puerta de entrada a la selva amazónica peruana. Explora la biodiversidad más rica del planeta y vive experiencias únicas en la naturaleza.",
        imagen: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=250&fit=crop",
        rating: 5,
        precio: "S/. 300",
        categoria: "Naturaleza",
        duracion: "3-4 días"
    },
    {
        id: 5,
        nombre: "Oasis de Huacachina",
        ubicacion: "Ica",
        descripcion: "Un oasis natural en medio del desierto, perfecto para sandboarding y paseos en tubulares. Una experiencia única entre dunas doradas.",
        imagen: "https://images.unsplash.com/photo-1582719471384-894fbb16e074?w=400&h=250&fit=crop",
        rating: 4,
        precio: "S/. 120",
        categoria: "Aventura",
        duracion: "1 día"
    },
    {
        id: 6,
        nombre: "Islas Ballestas - Paracas",
        ubicacion: "Ica",
        descripcion: "Conocidas como las 'Galápagos peruanas', hogar de lobos marinos, pingüinos de Humboldt y una gran variedad de aves marinas.",
        imagen: "https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?w=400&h=250&fit=crop",
        rating: 4,
        precio: "S/. 100",
        categoria: "Naturaleza",
        duracion: "Medio día"
    }
];
// Hacer disponible globalmente
window.sitiosTuristicos = sitiosTuristicos;
