// Componente principal de la aplicación
const { useState, useEffect } = React;

// Componente para mostrar las estrellas de rating
const Rating = ({ rating }) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
        stars.push(
            <i 
                key={i} 
                className={`fas fa-star ${i <= rating ? 'text-warning' : 'text-muted'}`}
            ></i>
        );
    }
    return <div className="rating">{stars}</div>;
};

// Componente para cada tarjeta de sitio turístico
const SitioCard = ({ sitio }) => {
    return (
        <div className="col-lg-4 col-md-6 mb-4">
            <div className="card site-card h-100 fade-in-up">
                <img 
                    src={sitio.imagen} 
                    className="card-img-top" 
                    alt={sitio.nombre}
                    onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/400x250?text=Imagen+No+Disponible';
                    }}
                />
                <div className="card-body d-flex flex-column">
                    <h5 className="card-title">
                        <i className="fas fa-map-marker-alt me-2"></i>
                        {sitio.nombre}
                    </h5>
                    <p className="text-muted mb-2">
                        <i className="fas fa-location-dot me-1"></i>
                        {sitio.ubicacion}
                    </p>
                    <p className="card-text flex-grow-1">{sitio.descripcion}</p>
                    
                    <div className="mb-3">
                        <Rating rating={sitio.rating} />
                    </div>
                    
                    <div className="row mb-2">
                        <div className="col-6">
                            <small className="text-muted">
                                <i className="fas fa-tag me-1"></i>
                                {sitio.categoria}
                            </small>
                        </div>
                        <div className="col-6">
                            <small className="text-muted">
                                <i className="fas fa-clock me-1"></i>
                                {sitio.duracion}
                            </small>
                        </div>
                    </div>
                    
                    <div className="d-flex justify-content-between align-items-center mt-auto">
                        <span className="h5 text-primary mb-0">{sitio.precio}</span>
                        <button className="btn btn-primary">
                            <i className="fas fa-info-circle me-2"></i>
                            Ver Detalles
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// Componente del encabezado
const Header = () => {
    return (
        <header className="hero-section">
            <div className="container">
                <h1 className="hero-title">
                    <i className="fas fa-mountain me-3"></i>
                    Descubre Perú
                </h1>
                <p className="hero-subtitle">
                    Explora los destinos más increíbles del país de los Incas
                </p>
                <div className="mt-4">
                    <button className="btn btn-light btn-lg me-3">
                        <i className="fas fa-compass me-2"></i>
                        Explorar Destinos
                    </button>
                    <button className="btn btn-outline-light btn-lg">
                        <i className="fas fa-phone me-2"></i>
                        Contactanos
                    </button>
                </div>
            </div>
        </header>
    );
};

// Componente del footer
const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <h5>
                            <i className="fas fa-mountain me-2"></i>
                            Descubre Perú
                        </h5>
                        <p>Tu guía confiable para explorar las maravillas del Perú</p>
                    </div>
                    <div className="col-md-6">
                        <h6>Síguenos</h6>
                        <div className="social-links">
                            <a href="#" className="text-white me-3">
                                <i className="fab fa-facebook fa-2x"></i>
                            </a>
                            <a href="#" className="text-white me-3">
                                <i className="fab fa-instagram fa-2x"></i>
                            </a>
                            <a href="#" className="text-white">
                                <i className="fab fa-twitter fa-2x"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <hr className="my-4" />
                <p className="text-center">
                    &copy; 2024 Descubre Perú. Todos los derechos reservados.
                </p>
            </div>
        </footer>
    );
};

// Componente principal de la aplicación
const App = () => {
    const [sitios, setSitios] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filtroCategoria, setFiltroCategoria] = useState('Todos');

    // Cargar datos al iniciar
    useEffect(() => {
        // Simular carga de datos
        setTimeout(() => {
            setSitios(window.sitiosTuristicos || []);
            setLoading(false);
        }, 1000);
    }, []);

    // Obtener categorías únicas
    const categorias = ['Todos', ...new Set(sitios.map(sitio => sitio.categoria))];

    // Filtrar sitios por categoría
    const sitiosFiltrados = filtroCategoria === 'Todos' 
        ? sitios 
        : sitios.filter(sitio => sitio.categoria === filtroCategoria);

    if (loading) {
        return (
            <div className="loading">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Cargando...</span>
                </div>
                <p className="mt-3">Cargando destinos increíbles...</p>
            </div>
        );
    }

    return (
        <div>
            <Header />
            
            <main className="container my-5">
                <h2 className="section-title">
                    <i className="fas fa-compass me-3"></i>
                    Destinos Populares
                </h2>
                
                {/* Filtros por categoría */}
                <div className="text-center mb-4">
                    <div className="btn-group" role="group">
                        {categorias.map(categoria => (
                            <button
                                key={categoria}
                                type="button"
                                className={`btn ${filtroCategoria === categoria ? 'btn-primary' : 'btn-outline-primary'}`}
                                onClick={() => setFiltroCategoria(categoria)}
                            >
                                {categoria}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Grid de sitios turísticos */}
                <div className="row">
                    {sitiosFiltrados.map(sitio => (
                        <SitioCard key={sitio.id} sitio={sitio} />
                    ))}
                </div>

                {sitiosFiltrados.length === 0 && (
                    <div className="text-center py-5">
                        <i className="fas fa-search fa-3x text-muted mb-3"></i>
                        <h4>No se encontraron destinos</h4>
                        <p className="text-muted">Intenta con otra categoría</p>
                    </div>
                )}
            </main>
            
            <Footer />
        </div>
    );
};

// Renderizar la aplicación
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

